import { Renderer } from "../engine/Renderer";
import { ParticleSystem } from "../engine/ParticleSystem";
import { applyCameraTransform, restoreCamera } from "../engine/Camera";
import type { Camera } from "../engine/gameReducer";
import type { WorldConfig } from "@/config/worlds";
import type { PlayerState } from "../entities/Player";
import type { PartnerState } from "../entities/Partner";
import type { ObstacleState } from "../entities/Obstacle";
import type { HeartCollectibleState } from "../entities/HeartCollectible";
import type { MemoryCardState } from "../entities/MemoryCard";

const PLATFORM_DEFS = [
  { x: 400, w: 120 }, { x: 700, w: 100 },
  { x: 1050, w: 130 }, { x: 1400, w: 110 }, { x: 1800, w: 120 },
];

export interface WorldSceneState {
  time: number;
  particles: ParticleSystem;
  bgParticles: ParticleSystem;
  cloudX: number[];
  treePositions: number[];
  windTimer: number;
}

export function createWorldScene(canvasW: number, canvasH: number): WorldSceneState {
  const clouds = Array.from({ length: 7 }, (_, i) => (i / 7) * canvasW * 2);
  const trees = Array.from({ length: 14 }, (_, i) => 80 + i * 230 + Math.random() * 80);
  return {
    time: 0,
    particles: new ParticleSystem(),
    bgParticles: new ParticleSystem(),
    cloudX: clouds,
    treePositions: trees,
    windTimer: 0,
  };
}

export function updateWorldScene(
  s: WorldSceneState,
  dt: number,
  world: WorldConfig,
  canvasW: number,
  canvasH: number
): WorldSceneState {
  const time = s.time + dt;
  s.particles.update(dt);
  s.bgParticles.update(dt);

  // Emit ambient particles
  if (world.particleType === "petal" && Math.random() < 0.4) {
    s.bgParticles.emitPetals(canvasW, 1);
  } else if (world.particleType === "rain" && Math.random() < 0.8) {
    s.bgParticles.emitRain(canvasW, 3);
  } else if (world.particleType === "firefly" && Math.random() < 0.1) {
    s.bgParticles.emitFireflies(canvasW, canvasH, 1);
  } else if (world.particleType === "snow" && Math.random() < 0.5) {
    s.bgParticles.emitSnow(canvasW, 2);
  }

  // Move clouds
  const cloudX = s.cloudX.map(x => {
    const next = x + 18 * dt;
    return next > canvasW * 2 + 120 ? -120 : next;
  });

  return { ...s, time, cloudX };
}

export function drawWorldScene(
  r: Renderer,
  s: WorldSceneState,
  world: WorldConfig,
  player: PlayerState,
  partner: PartnerState,
  obstacles: ObstacleState[],
  hearts: HeartCollectibleState[],
  memCards: MemoryCardState[],
  cam: Camera,
  canvasW: number,
  canvasH: number
) {
  const ctx = r.ctx;
  const groundY = world.groundY * canvasH;

  // Sky
  r.drawSkyGradient(world.skyColors, canvasW, canvasH);

  // Background rain overlay (screen-space)
  if (world.hasRain) {
    s.bgParticles.draw(ctx);
  }

  // Clouds (parallax)
  ctx.save();
  ctx.translate(-cam.x * 0.2, 0);
  s.cloudX.forEach((cx, i) => {
    r.drawCloud(cx, 50 + (i % 3) * 35, 80 + (i % 3) * 30,
      world.id === 2 ? "rgba(100,120,160,0.3)" : "rgba(255,255,255,0.5)"
    );
  });
  ctx.restore();

  // World (camera space)
  applyCameraTransform(ctx, cam, canvasW, canvasH);

  // Ground
  r.drawGround(groundY, world.levelWidth, cam.x, world.groundColor, world.groundLineColor, canvasH);

  // Trees (only non-rain worlds)
  if (world.id !== 2 && world.id !== 4) {
    s.treePositions.forEach(tx => {
      r.drawTree(tx, groundY, 0.8 + Math.random() * 0.3,
        world.id === 1 ? "#7bc67e" : world.id === 5 ? "#d4a96a" : "#5aab5e"
      );
    });
  }

  // Platforms (world 3)
  if (world.hasPlatforms) {
    PLATFORM_DEFS.forEach(p => {
      r.drawPlatform(p.x, groundY - 90, p.w, world.accentColor);
    });
  }

  // Memory cards
  memCards.forEach(mc => {
    if (!mc.triggered) {
      r.drawMemoryCard(mc.x, mc.y, false, mc.title, s.time);
    }
  });

  // Hearts
  hearts.forEach(h => {
    if (!h.collected || h.collectAnim < 1) {
      r.drawHeartCollectible(h.x, h.y, 12, h.collectAnim);
    }
  });

  // Obstacles
  obstacles.forEach(o => {
    r.drawObstacle(
      o.x, groundY - 60, 44,
      o.symbol, o.label,
      o.flash > 0, o.bobOffset
    );
  });

  // Partner
  if (partner.visible) drawPartner(ctx, partner, s.time);

  // Player
  drawPlayer(ctx, player, s.time, world);

  // Foreground particles (petals/snow in world space)
  if (world.particleType !== "rain") {
    s.bgParticles.draw(ctx);
  }

  restoreCamera(ctx);

  // Foreground sparkles (screen space — on collect)
  s.particles.draw(ctx);
}

function drawPlayer(ctx: CanvasRenderingContext2D, p: PlayerState, time: number, world: WorldConfig) {
  const cx = p.x + 18;
  const by = p.y;
  const bob = p.onGround ? Math.sin(time * 3) * 1.5 : 0;
  const isSlowed = p.speed < 0.9;

  ctx.save();
  ctx.translate(cx, by);
  if (!p.facingRight) ctx.scale(-1, 1);

  // Shadow
  ctx.globalAlpha = 0.2;
  ctx.fillStyle = "#000";
  ctx.beginPath(); ctx.ellipse(0, 4, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  const legSwing = p.animState === "run" ? Math.sin(time * 8) * 12 : 0;

  // Legs
  ctx.fillStyle = "#2d2d6e";
  ctx.save(); ctx.translate(-7, -14 + bob); ctx.rotate(legSwing * Math.PI / 180);
  ctx.fillRect(-4, 0, 8, 16); ctx.restore();
  ctx.save(); ctx.translate(7, -14 + bob); ctx.rotate(-legSwing * Math.PI / 180);
  ctx.fillRect(-4, 0, 8, 16); ctx.restore();

  // Body
  const bodyColor = isSlowed ? "#ff6b6b" : "#4a90d9";
  ctx.fillStyle = bodyColor;
  ctx.beginPath(); ctx.roundRect(-13, -38 + bob, 26, 26, 6); ctx.fill();

  // Arms
  const armSwing = p.animState === "run" ? Math.sin(time * 8 + Math.PI) * 15 : 0;
  ctx.fillStyle = bodyColor;
  ctx.save(); ctx.translate(-13, -32 + bob); ctx.rotate(-armSwing * Math.PI / 180);
  ctx.fillRect(-6, 0, 7, 14); ctx.restore();
  ctx.save(); ctx.translate(13, -32 + bob); ctx.rotate(armSwing * Math.PI / 180);
  ctx.fillRect(-1, 0, 7, 14); ctx.restore();

  // Head
  ctx.fillStyle = "#ffcba4";
  ctx.beginPath(); ctx.arc(0, -46 + bob, 13, 0, Math.PI * 2); ctx.fill();

  // Eye
  ctx.fillStyle = "#333";
  ctx.beginPath(); ctx.arc(5, -47 + bob, 2.5, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.beginPath(); ctx.arc(6, -48 + bob, 1, 0, Math.PI * 2); ctx.fill();

  // Smile
  ctx.strokeStyle = "#333"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(2, -43 + bob, 4, 0.2, Math.PI - 0.2); ctx.stroke();

  // Hair
  ctx.fillStyle = "#2c1810";
  ctx.beginPath(); ctx.ellipse(0, -57 + bob, 12, 7, 0, Math.PI, 0); ctx.fill();

  ctx.restore();
}

function drawPartner(ctx: CanvasRenderingContext2D, p: PartnerState, time: number) {
  const cx = p.x + 18;
  const by = p.y;
  const bob = Math.sin(time * 2.5) * 2;

  ctx.save();
  ctx.translate(cx, by);
  if (!p.facingRight) ctx.scale(-1, 1);

  // Shadow
  ctx.globalAlpha = 0.2; ctx.fillStyle = "#000";
  ctx.beginPath(); ctx.ellipse(0, 4, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  // Dress
  ctx.fillStyle = "#ff7eb6";
  ctx.beginPath();
  ctx.moveTo(-16, -12 + bob); ctx.lineTo(-18, 0); ctx.lineTo(18, 0); ctx.lineTo(16, -12 + bob);
  ctx.closePath(); ctx.fill();

  // Body
  ctx.fillStyle = "#ff9fc8";
  ctx.beginPath(); ctx.roundRect(-11, -36 + bob, 22, 26, 6); ctx.fill();

  // Waving arm
  const wave = Math.sin(time * 3) * 20;
  ctx.fillStyle = "#ff9fc8";
  ctx.save(); ctx.translate(11, -30 + bob); ctx.rotate(-wave * Math.PI / 180);
  ctx.fillRect(-2, 0, 7, 12); ctx.restore();
  ctx.save(); ctx.translate(-11, -30 + bob); ctx.rotate(15 * Math.PI / 180);
  ctx.fillRect(-5, 0, 7, 12); ctx.restore();

  // Head
  ctx.fillStyle = "#ffcba4";
  ctx.beginPath(); ctx.arc(0, -46 + bob, 13, 0, Math.PI * 2); ctx.fill();

  // Eye
  ctx.fillStyle = "#333";
  ctx.beginPath(); ctx.ellipse(-5, -47 + bob, 3, 3.5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.beginPath(); ctx.arc(-4, -48.5 + bob, 1.2, 0, Math.PI * 2); ctx.fill();

  // Cheeks
  ctx.globalAlpha = 0.35; ctx.fillStyle = "#ff9bb5";
  ctx.beginPath(); ctx.ellipse(-8, -44 + bob, 4, 3, 0, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  // Smile
  ctx.strokeStyle = "#c0507a"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(-2, -43 + bob, 4, 0.2, Math.PI - 0.2); ctx.stroke();

  // Hair
  ctx.fillStyle = "#3d1f10";
  ctx.beginPath(); ctx.ellipse(0, -57 + bob, 13, 8, 0, Math.PI, 0); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-12, -51 + bob, 5, 10, -0.4, 0, Math.PI * 2); ctx.fill();

  ctx.restore();
}