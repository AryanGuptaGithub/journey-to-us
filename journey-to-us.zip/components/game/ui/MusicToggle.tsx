"use client";
import React from "react";

interface MusicToggleProps {
  on: boolean;
  onToggle: () => void;
}

export function MusicToggle({ on, onToggle }: MusicToggleProps) {
  return (
    <button
      onClick={onToggle}
      style={{
        position: "absolute", top: 12, right: 12,
        background: "rgba(0,0,0,0.5)",
        border: "1px solid rgba(255,126,182,0.4)",
        borderRadius: 8,
        color: on ? "#ff7eb6" : "#666",
        fontSize: 18,
        width: 36, height: 36,
        cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center",
        transition: "all 0.2s",
        zIndex: 20,
      }}
      aria-label={on ? "Mute music" : "Unmute music"}
    >
      {on ? "♪" : "♩"}
    </button>
  );
}
ENDOFFILE

cat > /home/claude/jrny/components/game/ui/DialogBox.tsx << 'ENDOFFILE'
"use client";
import React from "react";

interface DialogBoxProps {
  text: string;
  onClose?: () => void;
}

export function DialogBox({ text, onClose }: DialogBoxProps) {
  return (
    <div
      className="anim-slide-up"
      style={{
        position: "absolute", bottom: "18%", left: "50%",
        transform: "translateX(-50%)",
        background: "rgba(10,4,30,0.92)",
        border: "1px solid #ff7eb6",
        borderRadius: 12,
        padding: "14px 22px",
        maxWidth: "80%",
        textAlign: "center",
        pointerEvents: onClose ? "auto" : "none",
        cursor: onClose ? "pointer" : "default",
        zIndex: 10,
      }}
      onClick={onClose}
    >
      <p className="font-pixel" style={{ color: "#ffd5ee", fontSize: 7, lineHeight: 2.2 }}>
        {text}
      </p>
      {onClose && (
        <p className="font-pixel" style={{ color: "#ff7eb6", fontSize: 5, marginTop: 8, opacity: 0.7 }}>
          [ tap to continue ]
        </p>
      )}
    </div>
  );
}