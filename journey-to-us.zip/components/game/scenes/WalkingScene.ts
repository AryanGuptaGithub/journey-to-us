import { Renderer } from "../engine/Renderer";
import { ParticleSystem } from "../engine/ParticleSystem";
import type { WorldConfig } from "@/config/worlds";

export interface WalkingSceneState {
  time: number;
  particles: ParticleSystem;
  playerX: number;
  partnerX: number;
  doneTimer: number;
  textAlpha: number;
  textIndex: number;
  textTimer: number;
}

const MESSAGES = [
  "Side by side now ♡",
  "Every step together.",
  "Ready for the next chapter?",
];

export function createWalkingScene(canvasW: number): WalkingSceneState {
  return {
    time: 0,
    particles: new ParticleSystem(),
    playerX: canvasW * 0.3,
    partnerX: canvasW * 0.45,
    doneTimer: 0,
    textAlpha: 0,
    textIndex: 0,
    textTimer: 0,
  };
}

export function updateWalkingScene(
  s: WalkingSceneState,
  dt: number,
  canvasW: number,
  canvasH: number,
  onDone: () => void
): WalkingSceneState {
  const time = s.time + dt;

  // Walk together across screen
  const playerX = s.playerX + 55 * dt;
  const partnerX = s.partnerX + 55 * dt;

  // Emit hearts while walking
  if (Math.random() < 0.2) {
    s.particles.emitHeartBurst((playerX + partnerX) / 2, canvasH * 0.55, 2);
  }
  if (Math.random() < 0.3) s.particles.emitSparkles(
    playerX + Math.random() * 80, canvasH * 0.6, 1
  );
  s.particles.update(dt);

  let { textAlpha, textIndex, textTimer, doneTimer } = s;
  textTimer += dt;
  if (textTimer > 1.8 && textIndex < MESSAGES.length - 1) {
    textIndex++;
    textTimer = 0;
    textAlpha = 0;
  }
  textAlpha = Math.min(1, textAlpha + dt * 2);

  doneTimer += dt;
  if (doneTimer > 4.5) onDone();

  return { ...s, time, playerX, partnerX, textAlpha, textIndex, textTimer, doneTimer };
}

export function drawWalkingScene(
  r: Renderer,
  s: WalkingSceneState,
  world: WorldConfig,
  canvasW: number,
  canvasH: number
) {
  const ctx = r.ctx;
  const groundY = world.groundY * canvasH;

  r.drawSkyGradient(world.skyColors, canvasW, canvasH);
  r.drawGround(groundY, canvasW * 3, 0, world.groundColor, world.groundLineColor, canvasH);

  s.particles.draw(ctx);

  // Draw both walking
  const bob = Math.sin(s.time * 6) * 3;
  drawWalker(ctx, s.playerX, groundY, true, bob, s.time);
  drawWalker(ctx, s.partnerX, groundY, false, -bob, s.time);

  // Message
  const msg = MESSAGES[s.textIndex];
  r.drawPixelText(msg, canvasW / 2, canvasH * 0.2, 7, "#ff7eb6", "center", s.textAlpha);
}

function drawWalker(
  ctx: CanvasRenderingContext2D,
  x: number, groundY: number,
  isPlayer: boolean, bob: number, time: number
) {
  ctx.save();
  ctx.translate(x + 18, groundY);

  const legSwing = Math.sin(time * 8) * 12;

  if (isPlayer) {
    ctx.fillStyle = "#2d2d6e";
    ctx.save(); ctx.translate(-7, -14 + bob); ctx.rotate(legSwing * Math.PI / 180);
    ctx.fillRect(-4, 0, 8, 16); ctx.restore();
    ctx.save(); ctx.translate(7, -14 + bob); ctx.rotate(-legSwing * Math.PI / 180);
    ctx.fillRect(-4, 0, 8, 16); ctx.restore();
    ctx.fillStyle = "#4a90d9";
    ctx.beginPath(); ctx.roundRect(-13, -38 + bob, 26, 26, 6); ctx.fill();
    ctx.fillStyle = "#ffcba4";
    ctx.beginPath(); ctx.arc(0, -46 + bob, 13, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#2c1810";
    ctx.beginPath(); ctx.ellipse(0, -57 + bob, 12, 7, 0, Math.PI, 0); ctx.fill();
  } else {
    ctx.scale(-1, 1);
    ctx.fillStyle = "#ff7eb6";
    ctx.beginPath(); ctx.moveTo(-16, -12 + bob); ctx.lineTo(-18, 0);
    ctx.lineTo(18, 0); ctx.lineTo(16, -12 + bob); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#ff9fc8";
    ctx.beginPath(); ctx.roundRect(-11, -36 + bob, 22, 26, 6); ctx.fill();
    ctx.fillStyle = "#ffcba4";
    ctx.beginPath(); ctx.arc(0, -46 + bob, 13, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#3d1f10";
    ctx.beginPath(); ctx.ellipse(0, -57 + bob, 13, 8, 0, Math.PI, 0); ctx.fill();
  }

  ctx.restore();
}