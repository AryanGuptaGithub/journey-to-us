import { Renderer } from "../engine/Renderer";
import { ParticleSystem } from "../engine/ParticleSystem";
import type { WorldConfig } from "@/config/worlds";

export interface ReunionSceneState {
  time: number;
  particles: ParticleSystem;
  phase: "approach" | "slowdown" | "meet" | "hug" | "kiss" | "done";
  playerX: number;
  partnerX: number;
  hugProgress: number;
  textAlpha: number;
  doneTimer: number;
}

export function createReunionScene(canvasW: number): ReunionSceneState {
  return {
    time: 0,
    particles: new ParticleSystem(),
    phase: "approach",
    playerX: 80,
    partnerX: canvasW - 100,
    hugProgress: 0,
    textAlpha: 0,
    doneTimer: 0,
  };
}

export function updateReunionScene(
  s: ReunionSceneState,
  dt: number,
  canvasW: number,
  canvasH: number,
  onDone: () => void
): ReunionSceneState {
  const time = s.time + dt;
  let { phase, playerX, partnerX, hugProgress, textAlpha, doneTimer } = s;
  const midX = canvasW / 2;

  if (phase === "approach") {
    playerX  = Math.min(midX - 70, playerX  + 160 * dt);
    partnerX = Math.max(midX + 20,  partnerX - 140 * dt);
    if (playerX >= midX - 70) phase = "slowdown";
  } else if (phase === "slowdown") {
    playerX  = Math.min(midX - 45, playerX  + 60 * dt);
    partnerX = Math.max(midX + 5,   partnerX - 50 * dt);
    if (playerX >= midX - 45) phase = "meet";
  } else if (phase === "meet") {
    if (time > 0.8) {
      phase = "hug";
      s.particles.emitHeartBurst(midX, canvasH * 0.4, 20);
      s.particles.emitSparkles(midX, canvasH * 0.4, 25);
    }
  } else if (phase === "hug") {
    hugProgress = Math.min(1, hugProgress + dt * 1.2);
    textAlpha   = Math.min(1, textAlpha + dt * 1.5);
    if (time > 2.5) {
      s.particles.emitHeartBurst(midX, canvasH * 0.35, 6);
      if (time > 3.5) phase = "kiss";
    }
  } else if (phase === "kiss") {
    textAlpha = Math.min(1, textAlpha + dt);
    doneTimer += dt;
    if (doneTimer > 2.5) onDone();
  }

  s.particles.update(dt);
  return { ...s, time, phase, playerX, partnerX, hugProgress, textAlpha, doneTimer };
}

export function drawReunionScene(
  r: Renderer,
  s: ReunionSceneState,
  world: WorldConfig,
  canvasW: number,
  canvasH: number
) {
  const ctx = r.ctx;
  const groundY = world.groundY * canvasH;

  // Background
  r.drawSkyGradient(world.skyColors, canvasW, canvasH);
  r.drawGround(groundY, canvasW * 3, 0, world.groundColor, world.groundLineColor, canvasH);

  const midX = canvasW / 2;

  // Glow at meet point
  if (s.phase === "hug" || s.phase === "kiss") {
    const glow = ctx.createRadialGradient(midX, groundY - 40, 0, midX, groundY - 40, 120);
    glow.addColorStop(0, `rgba(255,126,182,${0.4 * s.hugProgress})`);
    glow.addColorStop(1, "rgba(255,126,182,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, canvasW, canvasH);
  }

  // Draw characters
  drawCharAt(ctx, s.playerX, groundY, true, s.phase, s.time, false);
  drawCharAt(ctx, s.partnerX, groundY, false, s.phase, s.time, true);

  // Particles
  s.particles.draw(ctx);

  // Text
  if ((s.phase === "hug" || s.phase === "kiss") && s.textAlpha > 0) {
    const msg = s.phase === "kiss" ? "Together at last ♡" : "Finally...";
    r.drawPixelText(msg, midX, canvasH * 0.22, 10, "#ff7eb6", "center", s.textAlpha);
  }
}

function drawCharAt(
  ctx: CanvasRenderingContext2D,
  x: number, groundY: number,
  isPlayer: boolean,
  phase: string, time: number,
  isPartner: boolean
) {
  const bob = Math.sin(time * 2.5) * 2;
  const isHug = phase === "hug" || phase === "kiss";

  ctx.save();
  ctx.translate(x + 18, groundY);
  if (!isPlayer) ctx.scale(-1, 1);

  if (isPartner) {
    // Partner colours
    ctx.fillStyle = "#ff7eb6";
    ctx.beginPath(); ctx.moveTo(-16, -12 + bob); ctx.lineTo(-18, 0);
    ctx.lineTo(18, 0); ctx.lineTo(16, -12 + bob); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#ff9fc8";
    ctx.beginPath(); ctx.roundRect(-11, -36 + bob, 22, 26, 6); ctx.fill();
    // Hug arms stretch
    if (isHug) {
      ctx.fillStyle = "#ff9fc8";
      ctx.save(); ctx.translate(-11, -28 + bob); ctx.rotate(-50 * Math.PI / 180);
      ctx.fillRect(-5, 0, 7, 18); ctx.restore();
    }
    ctx.fillStyle = "#ffcba4";
    ctx.beginPath(); ctx.arc(0, -46 + bob, 13, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#3d1f10";
    ctx.beginPath(); ctx.ellipse(0, -57 + bob, 13, 8, 0, Math.PI, 0); ctx.fill();
    ctx.globalAlpha = 0.35; ctx.fillStyle = "#ff9bb5";
    ctx.beginPath(); ctx.ellipse(-8, -44 + bob, 4, 3, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
  } else {
    // Player colours
    ctx.fillStyle = "#2d2d6e";
    ctx.fillRect(-7, -14 + bob, 8, 16); ctx.fillRect(7, -14 + bob, 8, 16);
    ctx.fillStyle = "#4a90d9";
    ctx.beginPath(); ctx.roundRect(-13, -38 + bob, 26, 26, 6); ctx.fill();
    // Hug arms
    if (isHug) {
      ctx.fillStyle = "#4a90d9";
      ctx.save(); ctx.translate(13, -28 + bob); ctx.rotate(-45 * Math.PI / 180);
      ctx.fillRect(-2, 0, 7, 18); ctx.restore();
    }
    ctx.fillStyle = "#ffcba4";
    ctx.beginPath(); ctx.arc(0, -46 + bob, 13, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#2c1810";
    ctx.beginPath(); ctx.ellipse(0, -57 + bob, 12, 7, 0, Math.PI, 0); ctx.fill();
    ctx.fillStyle = "#333";
    ctx.beginPath(); ctx.arc(5, -47 + bob, 2.5, 0, Math.PI * 2); ctx.fill();
  }

  ctx.restore();
}