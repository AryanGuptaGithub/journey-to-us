"use client";
import dynamic from "next/dynamic";

const Game = dynamic(() => import("@/components/game/Game"), { ssr: false });

export default function Home() {
  return <Game />;
}